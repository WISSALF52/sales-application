# Systeme-de-Gestion-de-Stock-Vente-Stock-Sales-Management-System
![ges](https://user-images.githubusercontent.com/108725492/208992649-6c1c627d-1af6-40f1-a74b-a1e5e654b4b7.png)
![Capture d'écran_20221221_213647](https://user-images.githubusercontent.com/108725492/209002405-2ea91324-5bad-4026-877f-da1f33f6383c.png)
![Capture d'écran_20221221_213712](https://user-images.githubusercontent.com/108725492/209002419-a16ffa65-352b-4c8c-a3bd-7adf47d149e5.png)
![Capture d'écran_20221221_213752](https://user-images.githubusercontent.com/108725492/209002433-1dadce72-24af-4411-b079-0836256e9077.png)
![Capture d'écran_20221221_215738](https://user-images.githubusercontent.com/108725492/209002438-5057beb6-d4b3-45ef-a723-4313d8a15e1a.png)
![Capture d'écran_20221221_215847](https://user-images.githubusercontent.com/108725492/209002451-7f1f5ab6-776a-4f79-a32c-7b16bd9e9fda.png)
